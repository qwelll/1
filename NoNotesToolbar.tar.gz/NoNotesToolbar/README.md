# NoNotesToolbar v2.2（可切换模式的极简版）

隐藏 iOS「备忘录」键盘上方的编辑工具条（Aa / 清单 / 表格 / 相机 / 标记 / ✕）。

只针对 `com.apple.mobilenotes` 进程，只碰"用户界面类"，**绝不动 UIKit 键盘内部类**
（`UIInput* / UIKeyboard* / UIKB* / UIEditingOverlay*` 全部硬跳过）。

## 当前包的默认模式：MODE=3

没有配置文件时用默认值。**包里不含配置文件**，所以刚装完就是 `MODE=3`（连高度都不动，最保守）。

最新一次运行实际用了哪个模式，看日志第一行：

```bash
cat /var/mobile/Library/Logs/NoNotesToolbar.log
# === NoNotesToolbar v2.2 MODE=3: 首次处理 130 个类，补漏 3 个 ===
# （rootless 路径可能是 /var/jb/var/mobile/Library/Logs/NoNotesToolbar.log）
```

## 模式开关

配置文件 `/var/mobile/Media/NoNotesToolbar.cfg`，一行即可（改完重启备忘录生效，不用重新编译）：

```bash
echo 'MODE=3' > /var/mobile/Media/NoNotesToolbar.cfg
killall -9 MobileNotes
```

| MODE | 行为 | 说明 |
|---|---|---|
| 0 | 什么都不做 | 纯对照组：验证「欢迎页/震动」问题是否与本 tweak 无关 |
| 1 | `inputAccessoryView` 直接返回 `nil` | 外观最干净 |
| 2 | 保留原返回值，隐藏附件视图 + 高度归零 | 外观接近 1 |
| **3** | 保留原返回值，只 `hidden` + `alpha 0`，保留高度 | **默认**；最保守，会留一条空白 |

> 注意：v1.2 时代的 `A= / B= / C= / D= / E= / DUMP=` 写法在 v2.1 里不再识别，
> 如果 `/var/mobile/Media/NoNotesToolbar.cfg` 里有旧内容，请清理掉或直接写 `MODE=n`。

## 构建

```bash
export THEOS=~/theos
git clone --recursive https://github.com/theos/theos.git $THEOS

git clone --depth 1 --filter=blob:none --sparse https://github.com/theos/sdks ~/sdks
cd ~/sdks && git sparse-checkout set iPhoneOS16.5.sdk
export THEOS_SDKS_PATH=~/sdks

# 依赖：clang ldid dpkg-dev fakeroot make git xz-utils（macOS: brew install ldid dpkg xz）

cd NoNotesToolbar && make package FINALPACKAGE=1
```

产物 `packages/com.minis.notestoolbar_2.1.0_iphoneos-arm64.deb` → Sileo 安装 → `killall -9 MobileNotes`。

> `Makefile` 默认 `THEOS_PACKAGE_SCHEME = rootless`（装到 `/var/jb/...`）。
> rootful 越狱（unc0ver / checkra1n / palera1n rootful）请把那一行注释掉再编译。

没电脑 → 推到 GitHub，`.github/workflows/build.yml` 自动云编译，Artifacts 下载 deb。

## 排查

- **每次进备忘录弹「欢迎使用备忘录」+ 键盘震动消失** → 先把 `MODE=0` 跑一遍。
  若 MODE=0 下症状依旧，说明与本 tweak 无关；若消失，说明是"改返回值"惹的，保持默认 `MODE=3` 即可。
- 崩溃日志：`ls -lt /var/mobile/Library/Logs/CrashReporter/ | grep -i MobileNotes`
  （rootless 可能在 `/var/jb/var/mobile/Library/Logs/CrashReporter/`）。
- 工具条没隐藏（默认 MODE=3 下若仍有残留空白或未隐藏）→ 依次试 `MODE=2`、`MODE=1`。
- 默认 MODE=3 会保留附件视图的高度，所以键盘上方可能留一条空白色带；想要完全贴合，用 `MODE=2`。

## 已知限制

- 会一并去掉备忘录里**所有**输入框的 `inputAccessoryView`（不依赖具体类名的取舍）；其他 App 不受影响。
- 越狱更新 / 系统大版本升级后若失效，重新编译安装即可。
