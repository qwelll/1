# NoNotesToolbar v2.0（极简版）

隐藏 iOS「备忘录」键盘上方的编辑工具条（Aa / 清单 / 表格 / 相机 / 标记 / ✕）。

做法只有一件事：把 `com.apple.mobilenotes` 进程里**用户界面类**的 `-inputAccessoryView` 换成返回 `nil`。

**不做**：不碰 `UIInput* / UIKeyboard* / UIKB* / UIEditingOverlay*` 等 UIKit 键盘内部类；不扫描窗口或键盘容器；不写取证信息。

> 为什么这么克制：v1.0 把键盘内部类的方法也改成返回 nil，导致**键盘震动消失、布局异常**。v2.0 只动 App 自己的界面类，键盘子系统完全不受影响。

## 构建

```bash
export THEOS=~/theos
git clone --recursive https://github.com/theos/theos.git $THEOS

git clone --depth 1 --filter=blob:none --sparse https://github.com/theos/sdks ~/sdks
cd ~/sdks && git sparse-checkout set iPhoneOS16.5.sdk
export THEOS_SDKS_PATH=~/sdks

# 依赖：clang ldid dpkg-dev fakeroot make git xz-utils（macOS: brew install ldid dpkg xz）

cd NoNotesToolbar && make package FINALPACKAGE=1
```

产物：`packages/com.minis.notestoolbar_2.0.0_iphoneos-arm64.deb` → 用 Sileo / Zebra 安装 → 必要步骤：

```bash
killall -9 MobileNotes
```

> `Makefile` 里默认开了 `THEOS_PACKAGE_SCHEME = rootless`（装到 `/var/jb/...`）。
> 如果是 **rootful** 越狱（unc0ver / checkra1n / palera1n rootful），把那一行注释掉再编译。

没电脑 → 把工程推到 GitHub，`.github/workflows/build.yml` 会自动云编译出 deb，从 Artifacts 下载。

## 验证

装完重启备忘录进程，进去点正文弹出键盘 —— 那条工具条应该直接没了。

只在加载后写**一行**日志（不是取证）确认补丁生效：

```bash
cat /var/mobile/Library/Logs/NoNotesToolbar.log      # rootless 可能是 /var/jb/var/mobile/Library/Logs/
```

```
=== NoNotesToolbar v2.0: 首次替换 128 个类，补漏 3 个 ===
```

## 如果工具条还在

说明它不属于 App 自己的界面类（而是键盘侧托管的）。告诉我，我给你换 v2.1：不动返回值，只把返回的那条视图隐藏掉（保留键盘布局与触感）。

## 已知限制

- 会一并去掉备忘录里**所有**输入框的 `inputAccessoryView`（这是不依赖具体类名的取舍），其他 App 不受影响。
- 越狱更新 / 系统大版本升级后若失效，只需重新编译安装。
