# NoNotesToolbar (v1.2)

隐藏 iOS「备忘录」键盘上方的编辑工具条（Aa / 清单 / 表格 / 相机 / 标记 / ✕）。
只在 `com.apple.mobilenotes` 进程生效，不影响其他 App / 其他输入框。

## 版本历史（v1.0 的坑）

| 版本 | 说明 |
|---|---|
| v1.0 | 把进程内**所有**实现了 `inputAccessoryView` 的类都改成返回 nil。工具条确实消失了，但连带打掉了 `UIInputViewSet` / `UIInputWindowControllerHostingItem` / `UIKeyboardCandidateViewState` 等 **UIKit 键盘内部类** → **键盘触感消失、布局异常**。 |
| v1.1 | 加白名单跳过键盘内部类 + 全窗口扫描 + 取证模式。 |
| **v1.2** | 拦截点全部改成**运行时开关**（读 `NoNotesToolbar.cfg`，不用重新编译）；键盘内部类默认完全不碰；新增温和模式 C（保留原方法、只隐藏返回的附件视图）；视图加防重复处理标记。 |

## v1.2 运行时开关

配置文件：`/var/mobile/Media/NoNotesToolbar.cfg`（不存在就用默认值，改完重启备忘录生效）

```ini
A=1     # 界面类(UITextView/UITextField/WKWebView…) inputAccessoryView → nil   [默认 1]
B=0     # 键盘内部类 inputAccessoryView → nil（激进！可能坏键盘布局/触感）      [默认 0]
C=0     # 键盘内部类：保留原方法，只隐藏返回的附件视图（温和）                   [默认 0]
D=0     # 键盘弹出时递归扫描整个窗口，隐藏名字像工具条的视图                     [默认 0]
E=0     # 扫描键盘容器 UIInputSetHostView / UIInputSetContainerView            [默认 0]
DUMP=1  # 取证：把窗口里"条状视图"的类名 + frame 写进日志                        [默认 0]
```

**推荐用法**：保持默认 `A=1` 其余全 0。如果工具条没消失，再依次试 `C=1`、`E=1`、`D=1`，
每改一次只需 `killall -9 MobileNotes`，**不用重新编译**。

临时整体关闭：`/var/mobile/Media/NoNotesToolbar.off`（空文件）。

```
NoNotesToolbar/
├── Tweak.x                  # 源码（三层拦截）
├── Makefile
├── control
├── NoNotesToolbar.plist     # 过滤器：只注入备忘录
└── .github/workflows/build.yml
```

---

## 一、有电脑（推荐）：Theos 编译

macOS 或 Linux 都行。

```bash
# 1. 装 Theos
export THEOS=~/theos
git clone --recursive https://github.com/theos/theos.git $THEOS

# 2. 装 iOS SDK（挑一个你需要的版本）
git clone --depth 1 --filter=blob:none --sparse https://github.com/theos/sdks ~/sdks
cd ~/sdks && git sparse-checkout set iPhoneOS16.5.sdk
export THEOS_SDKS_PATH=~/sdks

# 3. 依赖：clang、ldid、dpkg-deb、fakeroot、make、git、xz
#    Debian/Ubuntu: sudo apt install clang ldid dpkg-dev fakeroot make git xz-utils
#    macOS:         brew install ldid dpkg xz

# 4. 编译
cd NoNotesToolbar
make package FINALPACKAGE=1
```

产物在 `packages/com.minis.notestoolbar_1.0.0_iphoneos-arm64.deb`。

用 **Sileo / Zebra** 直接打开这个 deb 安装，或：

```bash
scp packages/*.deb root@<设备IP>:/var/mobile/Documents/
# 设备上用 Sileo 打开 / 或在设备终端：dpkg -i /path/xxx.deb && killall -9 MobileNotes
```

### rootful 还是 rootless？
- **rootless**（Dopamine / palera1n rootless / 大多数新越狱）：`Makefile` 里已带 `THEOS_PACKAGE_SCHEME = rootless`，装到 `/var/jb/Library/MobileSubstrate/DynamicLibraries/`，**不用改**。
- **rootful**（unc0ver / checkra1n / palera1n rootful）：把那一行**注释掉**再编译。

> 装完必须重启备忘录进程：`killall -9 MobileNotes`（或重启桌面/设备）。

---

## 二、没电脑：GitHub Actions 云编译

1. 新建一个仓库，把 `NoNotesToolbar/` 里的文件按原结构推上去（`.github/workflows/build.yml` 会一起生效）。
2. 仓库 → **Actions** → 选 **build** → **Run workflow**。
3. 跑完在 **Artifacts** 里下载 `NoNotesToolbar-deb.zip`，解压得到 .deb，用 Sileo 安装。

---

## 三、完全不想编译：Flex 3 手搓补丁

越狱环境装 Flex 3（选支持 iOS 17 的 rootless 版本），

1. 打开 Flex → `+` → **Process** 选 **Notes（备忘录）**。
2. 添加 Patch → 方法搜索 `UIInputSetHostView` → 勾 `-(void)layoutSubviews`，用返回值/参数都留空即可。
   （更狠一点：搜索 **`inputAccessoryView`**，把命中的方法全部改成 **返回 nil**。）
3. 返回并启用补丁，进备忘录看看工具条是否消失。

Flex 的好处是不用编译、随手开关；坏处是每次重装 App / 升级系统可能要重做。

---

## 四、排查 / 微调

补丁加载后会写一份日志 `NoNotesToolbar.log`，**按顺序尝试 4 个位置**，写到哪个算哪个（日志第一行会注明实际路径）：

| 优先级 | 路径 | 说明 |
|---|---|---|
| 1 | `/var/mobile/Library/Logs/NoNotesToolbar.log` | rootful 越狱一般能写，最好找 |
| 2 | `/var/jb/var/mobile/Library/Logs/NoNotesToolbar.log` | rootless 越狱（`/var/jb` 前缀） |
| 3 | `/var/mobile/Media/NoNotesToolbar.log` | 共享目录，Filza 里好翻 |
| 4 | `<备忘录容器>/tmp/NoNotesToolbar.log` | 兜底，沙盒内一定写得进去 |

找不到就用 Filza 的搜索（🔍）直接搜 `NoNotesToolbar.log`；
或者在设备终端（NewTerm / Filza 终端）跑：

```bash
ls -l /var/mobile/Library/Logs/NoNotesToolbar.log
find /var/mobile/Containers/Data/Application -name "NoNotesToolbar.log" 2>/dev/null
```

备忘录的数据容器 UUID 可以用这条定位：

```bash
find /var/mobile/Containers/Data/Application -maxdepth 4 -name NoteStore.sqlite 2>/dev/null
# 同目录往上两级就是容器根，日志在 <容器>/tmp/NoNotesToolbar.log
```

⚠️ 注意：**日志只有补丁被真正加载后才会出现**——也就是 deb 装好、`killall -9 MobileNotes` 之后，再打开备忘录才会生成。没装或没生效的话，文件不存在是正常的。

把它发我，我就能确认工具条的真实类名，把"全杀 inputAccessoryView"改成精准点杀。

**临时关闭补丁**：在 `/var/mobile/Media/` 下建一个空文件 `NoNotesToolbar.off`，重启备忘录即恢复原样。

---

## 日志怎么看（v1.1 取证模式）

打开备忘录、点进正文让键盘弹出来，日志里会出现：

```
--- 取证开始 ---
窗口 UIWindow isKey=1 frame=...
找到 N 个条状视图：
  d3 ICToolbarView  frame={{0, 620}, {430, 44}}  hidden=1
  ...
UIInputSetContainerView 子视图: ...
--- 取证结束 ---
```

- `hidden=1`：说明我的清扫**已经命中并隐藏了它** ✅
- 全是 `hidden=0`：说明工具条的真实类名不在关键字表里 → 把那个类名发我（或自己加到 `NNTLooksLikeToolbar` 的 `kw` 数组里）即可精准命中。



## 疑难排查

### 症状：每次进备忘录都弹「欢迎使用"备忘录"」/ 键盘震动消失 / 布局异常

三个症状同一原因：v1.0 的 `B` 类激进 hook 破坏了键盘子系统。

1. **装 v1.2**（默认 `B=0`，完全不碰键盘内部类），`killall -9 MobileNotes` 后再看：
   - 震动 → 检查 `设置 → 声音与触感 → 键盘反馈 → 触感`；若开着仍无震动，卸载 tweak + 注销一次验证是否恢复。
   - 布局 → 应变回原样。
2. **欢迎页每次弹** = "已看过欢迎页"的标记没写进去，通常是**进程退出时崩溃**导致的。确认：

   ```bash
   ls -lt /var/mobile/Library/Logs/CrashReporter/ | grep -i MobileNotes | head
   # rootless 路径可能是 /var/jb/var/mobile/Library/Logs/CrashReporter/
   ```

   有 `MobileNotes-*.ips` 且时间对得上 → 就是崩溃，v1.2 应该能止住。
3. **判定是不是本 tweak 引起**：Sileo 里临时卸载本 tweak（或放 `NoNotesToolbar.off`）+ 注销，
   再看欢迎页是否还出现。还出现就是越狱/系统侧问题，与本 tweak 无关。

### 症状：工具条没消失

在 `NoNotesToolbar.cfg` 里按 `A=1 → C=1 → E=1 → D=1` 逐个开启试，每次改完 `killall -9 MobileNotes`，**不用重新编译**。
仍不行就开 `DUMP=1`，把日志里"条状视图"名单发我。

## 已知限制

- 越狱更新 / 系统大版本升级后，`UIInputSetHostView` 这类私有类名可能变，需重新适配。
- `A=1` 会杀掉备忘录内**所有**输入框的 `inputAccessoryView`，这是为了不依赖具体类名的取舍；
  想更保守就用 `A=0` + `C=1`（只藏、不改返回值）。
