# NoNotesToolbar v3.0（最小爆炸半径版）

隐藏 iOS「备忘录」键盘上方的编辑工具条（Aa / 清单 / 表格 / 相机 / 标记 / ✕）。
只注入 `com.apple.mobilenotes`，**绝不动 UIKit 键盘内部类**（`UIInput* / UIKeyboard* / UIKB* / UIEditingOverlay*`）。

v2.x 会替换进程内 **130 个类**的 `inputAccessoryView`；v3.0 默认只替换你点名的 **1~5 个类**，用来判断副作用是不是"改得太多"造成的。

## ✅ 已验证可用配置（实测通过）

```ini
MODE=4
ONLY=UITextView,ICTextView,ICBaseTextView,ICTableColumnTextView,MobileNotes.InlineMenuButtonTextView
METHOD=hide
```

即本包默认配置：工具条消失，且**无键盘震动消失 / 无布局异常 / 无重复欢迎页**。

⚠️ 实测教训：**绝不能**退回到 `MODE=1/2/3`（全进程 130 个类一起替换）——
那会连带打坏私有框架的类，出现"键盘异常 + 每次进备忘录跳欢迎页"。
若要缩小范围，可以从 `ONLY=UITextView` 开始逐个加类试。

## 默认状态：MODE=4，只动 5 个类

```ini
MODE=4
ONLY=UITextView,ICTextView,ICBaseTextView,ICTableColumnTextView,MobileNotes.InlineMenuButtonTextView
METHOD=hide      # 保留返回值，只 hidden + alpha 0（不动高度）
```

## 配置 /var/mobile/Media/NoNotesToolbar.cfg

```bash
echo 'MODE=0' > /var/mobile/Media/NoNotesToolbar.cfg   # 改完这一行
killall -9 MobileNotes
```

| MODE | 行为 |
|---|---|
| **0** | 完全不做事（纯对照组：验证副作用是否与本 tweak 无关） |
| 1 | 全进程界面类 → `inputAccessoryView` 返回 `nil` |
| 2 | 全进程界面类 → 保留返回值，隐藏视图 + 高度归零 |
| 3 | 全进程界面类 → 保留返回值，只 `hidden` + `alpha 0`（保留高度） |
| **4** | **只处理 `ONLY=` 列出的类**（默认） |

`MODE=4` 时额外可设：

```ini
ONLY=UITextView                                   # 最小：只动一个方法
METHOD=nil                                        # nil | hide0 | hide（默认 hide）
```

日志会写清楚实际模式与被改的类：

```bash
tail -1 /var/mobile/Library/Logs/NoNotesToolbar.log
# === NoNotesToolbar v3.0 MODE=4 METHOD=hide: 首次 3，补漏 0 | UITextView(hide), ICTextView(hide) ===
```

## 排查顺序（重要）

1. `MODE=0` → 若"键盘异常 + 跳欢迎页"**依旧**：与本 tweak 无关（越狱侧 / 备忘录自身崩溃）。
2. `MODE=4` + `ONLY=UITextView` → 只动一个方法。若工具条消失且键盘正常，就是 v2.x "改太多"的问题。
3. 仍然异常 → 病根是"隐藏附件视图"这件事本身，或另有其因（查崩溃日志）。
4. 崩溃日志：

```bash
ls -lt /var/mobile/Library/Logs/CrashReporter/ | grep -i MobileNotes
# rootless 可能在 /var/jb/var/mobile/Library/Logs/CrashReporter/
```

## 构建

```bash
export THEOS=~/theos
git clone --recursive https://github.com/theos/theos.git $THEOS
git clone --depth 1 --filter=blob:none --sparse https://github.com/theos/sdks ~/sdks
cd ~/sdks && git sparse-checkout set iPhoneOS16.5.sdk
export THEOS_SDKS_PATH=~/sdks
# 依赖：clang ldid dpkg-dev fakeroot make git xz-utils（macOS: brew install ldid dpkg xz）
cd NoNotesToolbar && make package FINALPACKAGE=1
```

产物 `packages/com.minis.notestoolbar_3.0.0_iphoneos-arm64.deb` → Sileo 安装 → `killall -9 MobileNotes`。

> `Makefile` 默认 rootless（装到 `/var/jb/...`）；rootful 越狱把 `THEOS_PACKAGE_SCHEME = rootless` 注释掉。
> 没电脑 → 推 GitHub，`.github/workflows/build.yml` 自动云编译。

## 已知限制

- `MODE=1/2/3` 会去掉备忘录里**所有**输入框的 `inputAccessoryView`；`MODE=4` 只影响 `ONLY=` 里的类。
- `METHOD=hide` 会保留附件视图高度，键盘上方可能留一条空白色带；想收掉用 `METHOD=hide0`。
