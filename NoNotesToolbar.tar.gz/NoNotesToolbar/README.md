# NoNotesToolbar

隐藏 iOS「备忘录」键盘上方的编辑工具条（Aa / 清单 / 表格 / 相机 / 标记 / ✕）。
只在 `com.apple.mobilenotes` 进程生效，不影响其他 App / 其他输入框。

```
NoNotesToolbar/
├── Tweak.x                  # 源码（三层拦截）
├── Makefile
├── control
├── NoNotesToolbar.plist     # 过滤器：只注入备忘录
└── .github/workflows/build.yml
```

---

## 一、有电脑（推荐）：Theos 编译

macOS 或 Linux 都行。

```bash
# 1. 装 Theos
export THEOS=~/theos
git clone --recursive https://github.com/theos/theos.git $THEOS

# 2. 装 iOS SDK（挑一个你需要的版本）
git clone --depth 1 --filter=blob:none --sparse https://github.com/theos/sdks ~/sdks
cd ~/sdks && git sparse-checkout set iPhoneOS16.5.sdk
export THEOS_SDKS_PATH=~/sdks

# 3. 依赖：clang、ldid、dpkg-deb、fakeroot、make、git、xz
#    Debian/Ubuntu: sudo apt install clang ldid dpkg-dev fakeroot make git xz-utils
#    macOS:         brew install ldid dpkg xz

# 4. 编译
cd NoNotesToolbar
make package FINALPACKAGE=1
```

产物在 `packages/com.minis.notestoolbar_1.0.0_iphoneos-arm64.deb`。

用 **Sileo / Zebra** 直接打开这个 deb 安装，或：

```bash
scp packages/*.deb root@<设备IP>:/var/mobile/Documents/
# 设备上用 Sileo 打开 / 或在设备终端：dpkg -i /path/xxx.deb && killall -9 MobileNotes
```

### rootful 还是 rootless？
- **rootless**（Dopamine / palera1n rootless / 大多数新越狱）：`Makefile` 里已带 `THEOS_PACKAGE_SCHEME = rootless`，装到 `/var/jb/Library/MobileSubstrate/DynamicLibraries/`，**不用改**。
- **rootful**（unc0ver / checkra1n / palera1n rootful）：把那一行**注释掉**再编译。

> 装完必须重启备忘录进程：`killall -9 MobileNotes`（或重启桌面/设备）。

---

## 二、没电脑：GitHub Actions 云编译

1. 新建一个仓库，把 `NoNotesToolbar/` 里的文件按原结构推上去（`.github/workflows/build.yml` 会一起生效）。
2. 仓库 → **Actions** → 选 **build** → **Run workflow**。
3. 跑完在 **Artifacts** 里下载 `NoNotesToolbar-deb.zip`，解压得到 .deb，用 Sileo 安装。

---

## 三、完全不想编译：Flex 3 手搓补丁

越狱环境装 Flex 3（选支持 iOS 17 的 rootless 版本），

1. 打开 Flex → `+` → **Process** 选 **Notes（备忘录）**。
2. 添加 Patch → 方法搜索 `UIInputSetHostView` → 勾 `-(void)layoutSubviews`，用返回值/参数都留空即可。
   （更狠一点：搜索 **`inputAccessoryView`**，把命中的方法全部改成 **返回 nil**。）
3. 返回并启用补丁，进备忘录看看工具条是否消失。

Flex 的好处是不用编译、随手开关；坏处是每次重装 App / 升级系统可能要重做。

---

## 四、排查 / 微调

补丁加载后会往**备忘录沙盒的 tmp 目录**写一份日志 `NoNotesToolbar.log`，
里面记录了：被改成返回 nil 的类名、以及键盘输入容器的子视图类名。
用 Filza 找：`/var/mobile/Containers/Data/Application/<备忘录UUID>/tmp/NoNotesToolbar.log`
（Filza 里搜关键字 `NoNotesToolbar.log` 更快）。

把这份日志发我，我就能确认工具条的真实类名，把 `Tweak.x` 里的关键字改精准，做成"只隐藏工具条、绝不误伤键盘"。

**临时关闭补丁**：在 `/var/mobile/Media/` 下建一个空文件 `NoNotesToolbar.off`，重启备忘录即恢复原样。

---

## 已知限制

- 越狱更新 / 系统大版本升级后，`UIInputSetHostView` 这类私有类名可能变，需重新适配。
- 补丁会杀掉备忘录内**所有** `inputAccessoryView`（含正文以外的输入框），这是为了不依赖具体类名的取舍。
