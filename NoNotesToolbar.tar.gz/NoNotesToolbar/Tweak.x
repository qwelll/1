// NoNotesToolbar v3.0 —— 最小爆炸半径版
//
// 目的：分离病因。v2.x 会替换进程内 130 个类的 inputAccessoryView；
//       v3.0 的 MODE=4 只替换你指定的那 1~5 个类，其余一律不动。
//
// ── 配置 /var/mobile/Media/NoNotesToolbar.cfg ──────────────────────────
//   MODE=0   完全不做事（纯对照：验证"键盘异常/欢迎页"是否与本 tweak 无关）  [可用]
//   MODE=1   全进程界面类 → inputAccessoryView 返回 nil
//   MODE=2   全进程界面类 → 保留返回值，隐藏视图 + 高度归零
//   MODE=3   全进程界面类 → 保留返回值，只 hidden + alpha 0（保留高度）
//   MODE=4   只处理 ONLY= 列出的类（默认；最小爆炸半径）
//
//   ONLY=UITextView,ICTextView,...        MODE=4 时生效
//   METHOD=nil | hide0 | hide             MODE=4 的处理方式，默认 hide
//
// 例：只动备忘录自己的文本视图，别的一律不碰
//   MODE=4
//   ONLY=ICTextView,ICBaseTextView,ICTableColumnTextView,MobileNotes.InlineMenuButtonTextView
//   METHOD=hide
//
// 改完 killall -9 MobileNotes 生效。

#import <UIKit/UIKit.h>
#import <objc/runtime.h>

static int      gMode   = 4;
static NSString *gOnly  = @"UITextView,ICTextView,ICBaseTextView,ICTableColumnTextView,MobileNotes.InlineMenuButtonTextView";
static NSString *gMethod = @"hide";

static BOOL NNTIsKeyboardInternal(NSString *cn) {
    static NSArray *pre = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        pre = @[ @"UIInput", @"UIKeyboard", @"_UIInput", @"_UIKeyboard", @"TUIKeyboard",
                 @"UIKB", @"_UIKB", @"UIEditingOverlay", @"UIRemoteKeyboard" ];
    });
    for (NSString *p in pre) if ([cn hasPrefix:p]) return YES;
    return NO;
}

#pragma mark - 日志（单行，非取证）

static void NNTLogLine(NSString *line) {
    NSArray *paths = @[ @"/var/mobile/Library/Logs/NoNotesToolbar.log",
                        @"/var/jb/var/mobile/Library/Logs/NoNotesToolbar.log",
                        @"/var/mobile/Media/NoNotesToolbar.log",
                        [NSTemporaryDirectory() stringByAppendingPathComponent:@"NoNotesToolbar.log"] ];
    NSString *s = [line stringByAppendingString:@"\n"];
    for (NSString *p in paths) {
        FILE *f = fopen(p.UTF8String, "a");
        if (f) { fprintf(f, "%s", s.UTF8String); fclose(f); return; }
    }
}

#pragma mark - 配置

static NSString *NNTTrim(NSString *s) {
    return [s stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
}

static void NNTLoadConfig(void) {
    NSString *cfg = [NSString stringWithContentsOfFile:@"/var/mobile/Media/NoNotesToolbar.cfg"
                                              encoding:NSUTF8StringEncoding error:NULL];
    if (!cfg) return;
    for (NSString *raw in [cfg componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]]) {
        NSString *line = NNTTrim(raw);
        if (line.length == 0 || [line hasPrefix:@"#"]) continue;
        NSRange eq = [line rangeOfString:@"="];
        if (eq.location == NSNotFound) continue;
        NSString *k = [NNTTrim([line substringToIndex:eq.location]) uppercaseString];
        NSString *v = NNTTrim([line substringFromIndex:eq.location + 1]);
        if ([k isEqualToString:@"MODE"]) {
            int m = v.intValue;
            if (m >= 0 && m <= 4) gMode = m;
        } else if ([k isEqualToString:@"ONLY"])    gOnly   = v;
        else if ([k isEqualToString:@"METHOD"])    gMethod = v.lowercaseString;
    }
}

#pragma mark - 替换实现

static id NNTNilInputAccessoryView(id self, SEL _cmd) { return nil; }

// keepHeight=YES 时只做 hidden + alpha 0；NO 时额外把高度归零
static IMP NNTHidingWrapper(Method m, SEL sel, BOOL keepHeight) {
    IMP orig = method_getImplementation(m);
    return imp_implementationWithBlock(^id(id _self) {
        UIView *v = ((id (*)(id, SEL))orig)(_self, sel);
        if (v && [v isKindOfClass:[UIView class]]) {
            v.hidden = YES;
            v.alpha  = 0.0;
            if (!keepHeight) {
                CGRect r = v.frame;
                r.size.height = 0.0;
                v.frame = r;
            }
        }
        return v;
    });
}

static CFMutableSetRef gDone = NULL;
static NSMutableArray *gTouched = nil;

static BOOL NNTApply(Class cls, SEL sel, IMP baseIMP, NSString *method) {
    if (!cls) return NO;
    if (!class_respondsToSelector(cls, sel)) return NO;
    Method m = class_getInstanceMethod(cls, sel);
    if (!m) return NO;
    if (CFSetContainsValue(gDone, m)) return NO;
    IMP cur = method_getImplementation(m);
    if (cur == baseIMP || cur == (IMP)NNTNilInputAccessoryView) return NO;

    if ([method isEqualToString:@"nil"])         method_setImplementation(m, (IMP)NNTNilInputAccessoryView);
    else if ([method isEqualToString:@"hide0"])  method_setImplementation(m, NNTHidingWrapper(m, sel, NO));
    else                                         method_setImplementation(m, NNTHidingWrapper(m, sel, YES));

    CFSetAddValue(gDone, m);
    [gTouched addObject:[NSString stringWithFormat:@"%@(%@)", NSStringFromClass(cls), method]];
    return YES;
}

static int NNTPatch(void) {
    if (gMode == 0) return 0;

    SEL sel = @selector(inputAccessoryView);
    IMP baseIMP = class_getMethodImplementation([UIResponder class], sel);

    if (!gDone)   gDone   = CFSetCreateMutable(NULL, 0, NULL);
    if (!gTouched) gTouched = [NSMutableArray array];

    int n = 0;

    if (gMode == 4) {
        // 只动 ONLY 里点名的类
        for (NSString *raw in [gOnly componentsSeparatedByString:@","]) {
            NSString *cn = NNTTrim(raw);
            if (cn.length == 0) continue;
            if (NNTIsKeyboardInternal(cn)) continue;
            Class cls = NSClassFromString(cn);
            if (!cls) { NNTLogLine([NSString stringWithFormat:@"[跳过] 找不到类 %@", cn]); continue; }
            if (NNTApply(cls, sel, baseIMP, gMethod)) n++;
        }
    } else {
        NSString *method = (gMode == 1) ? @"nil" : (gMode == 2 ? @"hide0" : @"hide");
        unsigned int count = 0;
        Class *classes = objc_copyClassList(&count);
        if (classes) {
            for (unsigned int i = 0; i < count; i++) {
                Class cls = classes[i];
                NSString *cn = NSStringFromClass(cls);
                if (!cn || NNTIsKeyboardInternal(cn)) continue;
                if (NNTApply(cls, sel, baseIMP, method)) n++;
            }
            free(classes);
        }
    }
    return n;
}

#pragma mark - 入口

%ctor {
    NNTLoadConfig();
    int n1 = NNTPatch();
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        int n2 = NNTPatch();
        NSString *detail = gTouched.count ? [gTouched componentsJoinedByString:@", "] : @"(未处理任何类)";
        NNTLogLine([NSString stringWithFormat:
            @"=== NoNotesToolbar v3.0 MODE=%d METHOD=%@: 首次 %d，补漏 %d | %@ ===",
            gMode, (gMode == 4 ? gMethod : @"-"), n1, n2, detail]);
    });
}
