// NoNotesToolbar v2.0 —— 极简版
//
// 只做一件事：把「备忘录」进程里**用户界面类**的 -inputAccessoryView 变成 nil，
// 于是键盘上方那条编辑工具条（Aa / 清单 / 表格 / 相机 / 标记 / ✕）就不存在了。
//
// 刻意不做的事（避免 v1.0 的副作用）：
//   ✗ 不碰任何 UIKit 键盘内部类（UIInput* / UIKeyboard* / UIKB* / UIEditingOverlay* …）
//   ✗ 不扫描窗口 / 不扫键盘容器视图
//   ✗ 不写取证信息（只在加载时留一行日志）
//
// 作用范围：过滤器只注入 com.apple.mobilenotes，其他 App 完全不受影响。

#import <UIKit/UIKit.h>
#import <objc/runtime.h>

#pragma mark - 白名单：UIKit 键盘内部类，绝对不碰

static BOOL NNTIsKeyboardInternal(NSString *cn) {
    static NSArray *pre = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        pre = @[ @"UIInput", @"UIKeyboard", @"_UIInput", @"_UIKeyboard", @"TUIKeyboard",
                 @"UIKB", @"_UIKB", @"UIEditingOverlay", @"UIRemoteKeyboard" ];
    });
    for (NSString *p in pre) if ([cn hasPrefix:p]) return YES;
    return NO;
}

#pragma mark - 替换实现

static id NNTNilInputAccessoryView(id self, SEL _cmd) { return nil; }

static int NNTPatch(void) {
    SEL sel = @selector(inputAccessoryView);
    IMP baseIMP = class_getMethodImplementation([UIResponder class], sel);

    unsigned int count = 0;
    Class *classes = objc_copyClassList(&count);
    if (!classes) return 0;

    // 同一个实现常被多个子类共享，按 Method 去重，避免重复替换
    static CFMutableSetRef done = NULL;
    if (!done) done = CFSetCreateMutable(NULL, 0, NULL);

    int n = 0;
    for (unsigned int i = 0; i < count; i++) {
        Class cls = classes[i];
        NSString *cn = NSStringFromClass(cls);
        if (!cn) continue;
        if (NNTIsKeyboardInternal(cn)) continue;              // 键盘内部类：跳过
        if (!class_respondsToSelector(cls, sel)) continue;
        Method m = class_getInstanceMethod(cls, sel);
        if (!m) continue;
        if (CFSetContainsValue(done, m)) continue;
        IMP cur = method_getImplementation(m);
        if (cur == baseIMP || cur == (IMP)NNTNilInputAccessoryView) continue;
        method_setImplementation(m, (IMP)NNTNilInputAccessoryView);
        CFSetAddValue(done, m);
        n++;
    }
    free(classes);
    return n;
}

#pragma mark - 入口

%ctor {
    int n1 = NNTPatch();

    // 有少数类在启动之后才动态注册，2 秒后补一次（同一个替换，幂等）
    __block int n2 = 0;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        n2 = NNTPatch();
        // 一行加载日志（不是取证），便于出问题时确认补丁是否生效
        NSString *line = [NSString stringWithFormat:
            @"=== NoNotesToolbar v2.0: 首次替换 %d 个类，补漏 %d 个 ===\n", n1, n2];
        NSArray *paths = @[ @"/var/mobile/Library/Logs/NoNotesToolbar.log",
                            @"/var/jb/var/mobile/Library/Logs/NoNotesToolbar.log",
                            @"/var/mobile/Media/NoNotesToolbar.log",
                            [NSTemporaryDirectory() stringByAppendingPathComponent:@"NoNotesToolbar.log"] ];
        for (NSString *p in paths) {
            FILE *f = fopen(p.UTF8String, "a");
            if (f) { fprintf(f, "%s", line.UTF8String); fclose(f); break; }
        }
    });
}
