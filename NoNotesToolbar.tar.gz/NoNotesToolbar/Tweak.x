// NoNotesToolbar v2.2 —— 可切换模式的极简版（用于分离病因）
//
// 只针对 com.apple.mobilenotes 进程，只碰"用户界面类"，绝不动 UIKit 键盘内部类。
//
// ── 模式开关：/var/mobile/Media/NoNotesToolbar.cfg，内容一行 ──
//   MODE=0   什么都不做（纯对照组：用来确认"欢迎页/震动"问题是否与本 tweak 无关）
//   MODE=1   inputAccessoryView 直接返回 nil（= v2.0 行为，外观最干净）
//   MODE=2   保留原返回值，把返回的附件视图隐藏 + 高度归零（外观接近 MODE=1）
//   MODE=3   保留原返回值，只 hidden + alpha 0，**保留高度**（默认；最保守，会留一条空白）
//
// 改完 killall -9 MobileNotes 即可生效，无需重新编译。

#import <UIKit/UIKit.h>
#import <objc/runtime.h>

static int gMode = 3;

static BOOL NNTIsKeyboardInternal(NSString *cn) {
    static NSArray *pre = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        pre = @[ @"UIInput", @"UIKeyboard", @"_UIInput", @"_UIKeyboard", @"TUIKeyboard",
                 @"UIKB", @"_UIKB", @"UIEditingOverlay", @"UIRemoteKeyboard" ];
    });
    for (NSString *p in pre) if ([cn hasPrefix:p]) return YES;
    return NO;
}

static void NNTLogLine(NSString *line) {
    NSArray *paths = @[ @"/var/mobile/Library/Logs/NoNotesToolbar.log",
                        @"/var/jb/var/mobile/Library/Logs/NoNotesToolbar.log",
                        @"/var/mobile/Media/NoNotesToolbar.log",
                        [NSTemporaryDirectory() stringByAppendingPathComponent:@"NoNotesToolbar.log"] ];
    NSString *s = [line stringByAppendingString:@"\n"];
    for (NSString *p in paths) {
        FILE *f = fopen(p.UTF8String, "a");
        if (f) { fprintf(f, "%s", s.UTF8String); fclose(f); return; }
    }
}

static int NNTLoadMode(void) {
    NSString *cfg = [NSString stringWithContentsOfFile:@"/var/mobile/Media/NoNotesToolbar.cfg"
                                              encoding:NSUTF8StringEncoding error:NULL];
    for (NSString *raw in [cfg componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]]) {
        NSString *line = [raw stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        if (![line.uppercaseString hasPrefix:@"MODE="]) continue;
        int v = [[line substringFromIndex:5] intValue];
        if (v >= 0 && v <= 3) return v;
    }
    return 3;
}

#pragma mark - 两种处理方式

static id NNTNilInputAccessoryView(id self, SEL _cmd) { return nil; }

// 保留原实现，只处理它返回的视图；keepHeight=YES 时不动高度
static IMP NNTHidingWrapper(Method m, SEL sel, BOOL keepHeight) {
    IMP orig = method_getImplementation(m);
    return imp_implementationWithBlock(^id(id _self) {
        UIView *v = ((id (*)(id, SEL))orig)(_self, sel);
        if (v && [v isKindOfClass:[UIView class]]) {
            v.hidden = YES;
            v.alpha  = 0.0;
            if (!keepHeight) {
                CGRect r = v.frame;
                r.size.height = 0.0;
                v.frame = r;
            }
        }
        return v;
    });
}

#pragma mark - 遍历替换

static int NNTPatch(void) {
    if (gMode == 0) return 0;

    SEL sel = @selector(inputAccessoryView);
    IMP baseIMP = class_getMethodImplementation([UIResponder class], sel);

    unsigned int count = 0;
    Class *classes = objc_copyClassList(&count);
    if (!classes) return 0;

    static CFMutableSetRef done = NULL;
    if (!done) done = CFSetCreateMutable(NULL, 0, NULL);

    int n = 0;
    for (unsigned int i = 0; i < count; i++) {
        Class cls = classes[i];
        NSString *cn = NSStringFromClass(cls);
        if (!cn) continue;
        if (NNTIsKeyboardInternal(cn)) continue;
        if (!class_respondsToSelector(cls, sel)) continue;
        Method m = class_getInstanceMethod(cls, sel);
        if (!m) continue;
        if (CFSetContainsValue(done, m)) continue;
        IMP cur = method_getImplementation(m);
        if (cur == baseIMP || cur == (IMP)NNTNilInputAccessoryView) continue;

        switch (gMode) {
            case 1: method_setImplementation(m, (IMP)NNTNilInputAccessoryView); break;
            case 2: method_setImplementation(m, NNTHidingWrapper(m, sel, NO));  break;
            case 3: method_setImplementation(m, NNTHidingWrapper(m, sel, YES)); break;
            default: break;
        }
        CFSetAddValue(done, m);
        n++;
    }
    free(classes);
    return n;
}

#pragma mark - 入口

%ctor {
    gMode = NNTLoadMode();
    int n1 = NNTPatch();
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        int n2 = NNTPatch();
        NNTLogLine([NSString stringWithFormat:
            @"=== NoNotesToolbar v2.2 MODE=%d: 首次处理 %d 个类，补漏 %d 个 ===", gMode, n1, n2]);
    });
}
