// NoNotesToolbar —— 隐藏「备忘录」键盘上方的编辑工具条（Aa / 清单 / 表格 / 相机 / 标记 / ✕）
// 只在 com.apple.mobilenotes 进程内生效，不影响其他 App。
// 三层拦截，任何一层命中即可生效：
//   1) 把进程内所有实现了 -inputAccessoryView 的类统一改成返回 nil
//   2) 递归清扫 UIInputSetHostView / UIInputSetContainerView 里名字像工具条的视图
//   3) 兜底：layout 之后再次清零高度
// 若只想临时关闭：在 /var/mobile/Media/ 下放一个空文件 NoNotesToolbar.off

#import <UIKit/UIKit.h>
#import <objc/runtime.h>

static BOOL gEnabled = YES;
static BOOL gLogged  = NO;

#pragma mark - 日志（写到备忘录自己的 tmp 目录，方便排查）

static void NNTLog(NSString *line) {
    NSString *p = [NSTemporaryDirectory() stringByAppendingPathComponent:@"NoNotesToolbar.log"];
    FILE *f = fopen(p.UTF8String, "a");
    if (!f) return;
    fprintf(f, "%s\n", line.UTF8String);
    fclose(f);
}

#pragma mark - 判定 & 隐藏

static BOOL NNTLooksLikeToolbar(UIView *v) {
    if (!v) return NO;
    NSString *cn = NSStringFromClass(v.class);
    static NSArray *kw = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        kw = @[ @"Toolbar", @"Accessory", @"FormatBar", @"EditorBar", @"ShortcutBar" ];
    });
    for (NSString *k in kw) {
        if ([cn rangeOfString:k].location != NSNotFound) return YES;
    }
    return NO;
}

static BOOL NNTIsKeyboard(UIView *v) {
    NSString *cn = NSStringFromClass(v.class);
    NSArray *kw = @[ @"Keyboard", @"Keyplane", @"Keyplane", @"Candidate", @"Emoji", @"Predictive" ];
    for (NSString *k in kw) {
        if ([cn rangeOfString:k].location != NSNotFound) return YES;
    }
    return NO;
}

static void NNTHide(UIView *v) {
    v.hidden = YES;
    v.alpha  = 0.0;
    CGRect f = v.frame;
    f.size.height = 0.0;
    v.frame = f;
}

// 递归清扫（键盘本体不进入）
static void NNTSweep(UIView *v, int depth) {
    if (!v || depth > 6) return;
    if (NNTLooksLikeToolbar(v)) { NNTHide(v); return; }
    if (depth > 0 && NNTIsKeyboard(v)) return;
    for (UIView *s in [v.subviews copy]) NNTSweep(s, depth + 1);
}

#pragma mark - 1) 干掉 inputAccessoryView

static id NNTNilInputAccessoryView(id self, SEL _cmd) { return nil; }

static void NNTKillInputAccessoryViews(void) {
    unsigned int count = 0;
    Class *classes = objc_copyClassList(&count);
    if (!classes) return;
    SEL sel = @selector(inputAccessoryView);
    IMP baseIMP = class_getMethodImplementation([UIResponder class], sel);
    NSMutableArray *hit = [NSMutableArray array];
    for (unsigned int i = 0; i < count; i++) {
        Class cls = classes[i];
        if (!class_respondsToSelector(cls, sel)) continue;
        Method m = class_getInstanceMethod(cls, sel);
        if (!m) continue;
        if (method_getImplementation(m) == baseIMP) continue;   // 没重写的不用管
        method_setImplementation(m, (IMP)NNTNilInputAccessoryView);
        [hit addObject:NSStringFromClass(cls)];
    }
    free(classes);
    if (hit.count) NNTLog([NSString stringWithFormat:@"[inputAccessoryView→nil] %@", hit]);
}

#pragma mark - 2/3) 清扫键盘容器

%hook UIInputSetHostView
- (void)layoutSubviews {
    %orig;
    if (gEnabled) NNTSweep(self, 0);
}
- (void)didAddSubview:(UIView *)subview {
    %orig;
    if (gEnabled) NNTSweep(subview, 0);
}
%end

%hook UIInputSetContainerView
- (void)layoutSubviews {
    %orig;
    if (gEnabled) NNTSweep(self, 0);
    if (!gLogged) {
        gLogged = YES;
        NSMutableArray *names = [NSMutableArray array];
for (UIView *v in ((UIView *)self).subviews) [names addObject:NSStringFromClass(v.class)];
        NNTLog([NSString stringWithFormat:@"[输入容器子视图] %@", names]);
    }
}
%end

#pragma mark - 入口

%ctor {
    // 开关（读不到就当开启）
    if ([[NSFileManager defaultManager] fileExistsAtPath:@"/var/mobile/Media/NoNotesToolbar.off"]) {
        gEnabled = NO;
    }
    NNTLog([NSString stringWithFormat:@"=== NoNotesToolbar loaded, enabled=%d ===", gEnabled]);
    if (!gEnabled) return;

    NNTKillInputAccessoryViews();
    // 有些类在启动后才动态注册，补两刀
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NNTKillInputAccessoryViews();
    });
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(6.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NNTKillInputAccessoryViews();
    });
}
