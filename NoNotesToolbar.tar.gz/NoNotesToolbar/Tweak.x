// NoNotesToolbar v1.2 —— 隐藏「备忘录」键盘上方的编辑工具条
// 只在 com.apple.mobilenotes 进程内生效。
//
// 相比 v1.0 / v1.1：
//   · 所有拦截点做成"运行时可配置"，改 /var/mobile/Media/NoNotesToolbar.cfg 即可，无需重新编译
//   · 键盘内部类（UIInput*/UIKeyboard*/UIKB*）默认**完全不碰**（v1.0 的元凶：把它们的
//     inputAccessoryView 改成返回 nil，破坏了键盘布局与触感反馈）
//   · 提供温和模式 C：保留键盘内部类的方法，只把返回的附件视图藏起来
//
// ── 配置文件 /var/mobile/Media/NoNotesToolbar.cfg（不存在则用默认）──
//   A=1   把用户界面类（UITextView/UITextField/WKWebView 等）的 inputAccessoryView 改为 nil   [默认 1]
//   B=0   把键盘内部类的 inputAccessoryView 也改为 nil（激进，可能坏键盘布局/触感）           [默认 0]
//   C=0   键盘内部类的 inputAccessoryView 保留返回，但把返回的视图隐藏（温和）                 [默认 0]
//   D=0   键盘弹出时递归扫描整个窗口，隐藏名字像工具条的视图                                  [默认 0]
//   E=0   扫描键盘容器 UIInputSetHostView / UIInputSetContainerView                          [默认 0]
//   DUMP=1 取证：把窗口里"条状视图"的类名+frame 写进日志                                      [默认 0]
//
// 临时整体关闭：/var/mobile/Media/NoNotesToolbar.off

#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#include <unistd.h>

static BOOL gEnabled = YES;
static BOOL gA = YES, gB = NO, gC = NO, gD = NO, gE = NO, gDump = NO;
static BOOL gDumped = NO;

#pragma mark - 日志

static NSString *NNTPath(void) {
    static NSString *chosen = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        NSArray *cands = @[
            @"/var/mobile/Library/Logs/NoNotesToolbar.log",
            @"/var/jb/var/mobile/Library/Logs/NoNotesToolbar.log",
            @"/var/mobile/Media/NoNotesToolbar.log",
            [NSTemporaryDirectory() stringByAppendingPathComponent:@"NoNotesToolbar.log"]
        ];
        for (NSString *p in cands) {
            FILE *f = fopen(p.UTF8String, "a");
            if (f) { fclose(f); chosen = p; break; }
        }
    });
    return chosen;
}

static void NNTLog(NSString *fmt, ...) {
    NSString *p = NNTPath();
    if (!p) return;
    va_list ap; va_start(ap, fmt);
    NSString *line = [[NSString alloc] initWithFormat:fmt arguments:ap];
    va_end(ap);
    FILE *f = fopen(p.UTF8String, "a");
    if (!f) return;
    fprintf(f, "%s\n", line.UTF8String);
    fclose(f);
}

#pragma mark - 配置

static void NNTLoadConfig(void) {
    NSString *cfg = [NSString stringWithContentsOfFile:@"/var/mobile/Media/NoNotesToolbar.cfg"
                                              encoding:NSUTF8StringEncoding error:NULL];
    NSMutableArray *parsed = [NSMutableArray array];
    for (NSString *raw in [cfg componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]]) {
        NSString *line = [raw stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        if (line.length == 0 || [line hasPrefix:@"#"]) continue;
        NSArray *kv = [line componentsSeparatedByString:@"="];
        if (kv.count != 2) continue;
        NSString *k = [[kv[0] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] uppercaseString];
        BOOL v = [[kv[1] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] boolValue];
        if      ([k isEqualToString:@"A"])    gA = v;
        else if ([k isEqualToString:@"B"])    gB = v;
        else if ([k isEqualToString:@"C"])    gC = v;
        else if ([k isEqualToString:@"D"])    gD = v;
        else if ([k isEqualToString:@"E"])    gE = v;
        else if ([k isEqualToString:@"DUMP"]) gDump = v;
        [parsed addObject:[NSString stringWithFormat:@"%@=%d", k, v]];
    }
    NNTLog(@"配置: A=%d B=%d C=%d D=%d E=%d DUMP=%d  %@", gA, gB, gC, gD, gE, gDump,
           parsed.count ? parsed : @"(使用默认)");
}

#pragma mark - 判定

static BOOL NNTAnyPrefix(NSString *s, NSArray *prefixes) {
    for (NSString *p in prefixes) if ([s hasPrefix:p]) return YES;
    return NO;
}

// UIKit 键盘内部类：默认一律不碰
static BOOL NNTIsKeyboardInternal(NSString *cn) {
    static NSArray *pre = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        pre = @[ @"UIInput", @"UIKeyboard", @"_UIInput", @"_UIKeyboard", @"TUIKeyboard",
                 @"UIKB", @"_UIKB", @"UIEditingOverlay", @"UIRemoteKeyboard" ];
    });
    return NNTAnyPrefix(cn, pre);
}

static BOOL NNTLooksLikeToolbar(UIView *v) {
    if (!v) return NO;
    NSString *cn = NSStringFromClass(v.class);
    if (NNTIsKeyboardInternal(cn)) return NO;
    static NSArray *kw = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        kw = @[ @"Toolbar", @"Accessory", @"FormatBar", @"FormattingBar", @"EditorBar",
                @"ShortcutBar", @"NoteBar", @"EditBar" ];
    });
    for (NSString *k in kw) if ([cn rangeOfString:k].location != NSNotFound) return YES;
    return NO;
}

// 隐藏：不删除视图，只让它不可见且不占位
static void NNTHide(UIView *v) {
    v.hidden = YES;
    v.alpha  = 0.0;
    CGRect f = v.frame;
    f.size.height = 0.0;
    v.frame = f;
}

#pragma mark - 清扫

static void NNTSweep(UIView *v, int depth) {
    if (!v || depth > 12) return;
    if (v.tag == 0x4E4E54) return;                     // 已处理标记，防重复
    if (NNTLooksLikeToolbar(v)) { v.tag = 0x4E4E54; NNTHide(v); return; }
    NSString *cn = NSStringFromClass(v.class);
    if (depth > 0 && NNTIsKeyboardInternal(cn)) return;
    for (UIView *s in [v.subviews copy]) NNTSweep(s, depth + 1);
}

static void NNTSweepWindows(void) {
    if (!gEnabled || !gD) return;
    for (UIWindow *w in [UIApplication sharedApplication].windows) {
        if (!w.isHidden) NNTSweep(w, 0);
    }
}

#pragma mark - 取证

static void NNTDump(UIView *v, int depth, NSMutableArray *hits) {
    if (!v || depth > 14) return;
    NSString *cn = NSStringFromClass(v.class);
    CGRect f = v.frame;
    if (depth > 0 && !NNTIsKeyboardInternal(cn) && f.size.height > 20 && f.size.height < 130
        && f.size.width > 200) {
        [hits addObject:[NSString stringWithFormat:@"  d%d %@ frame=%@ hidden=%d",
                         depth, cn, NSStringFromCGRect(f), v.hidden]];
    }
    if (depth > 0 && NNTIsKeyboardInternal(cn)) return;
    for (UIView *s in [v.subviews copy]) NNTDump(s, depth + 1, hits);
}

static void NNTDumpOnce(void) {
    if (!gDump || gDumped) return;
    gDumped = YES;
    NNTLog(@"--- 取证开始 ---");
    for (UIWindow *w in [UIApplication sharedApplication].windows) {
        if (w.isHidden) continue;
        NNTLog(@"窗口 %@ isKey=%d frame=%@", NSStringFromClass(w.class), w.isKeyWindow, NSStringFromCGRect(w.frame));
        NSMutableArray *hits = [NSMutableArray array];
        NNTDump(w, 0, hits);
        NNTLog(@"条状视图 %lu 个：", (unsigned long)hits.count);
        for (NSString *h in hits) NNTLog(@"%@", h);
    }
    NNTLog(@"--- 取证结束 ---");
}

#pragma mark - inputAccessoryView 处理

static id NNTNilInputAccessoryView(id self, SEL _cmd) { return nil; }

// 温和模式：保留原实现，只把返回的附件视图藏掉
static IMP NNTHidingWrapper(Method m, SEL sel) {
    IMP orig = method_getImplementation(m);
    return imp_implementationWithBlock(^id(id _self) {
        UIView *v = ((id (*)(id, SEL))orig)(_self, sel);
        if (v && [v isKindOfClass:[UIView class]]) NNTHide(v);
        return v;
    });
}

static void NNTPatchInputAccessoryViews(void) {
    unsigned int count = 0;
    Class *classes = objc_copyClassList(&count);
    if (!classes) return;

    SEL sel = @selector(inputAccessoryView);
    IMP baseIMP = class_getMethodImplementation([UIResponder class], sel);

    // 已处理过的 Method 去重（同一个实现常常被多个子类共享）
    static CFMutableSetRef done = NULL;
    if (!done) done = CFSetCreateMutable(NULL, 0, NULL);

    int nA = 0, nB = 0, nC = 0;
    for (unsigned int i = 0; i < count; i++) {
        Class cls = classes[i];
        NSString *cn = NSStringFromClass(cls);
        if (!cn) continue;
        if (!class_respondsToSelector(cls, sel)) continue;
        Method m = class_getInstanceMethod(cls, sel);
        if (!m) continue;
        if (CFSetContainsValue(done, m)) continue;
        IMP cur = method_getImplementation(m);
        if (cur == baseIMP) continue;                       // 没重写的跳过
        if (cur == (IMP)NNTNilInputAccessoryView) continue; // 已是我们的空实现

        BOOL internal = NNTIsKeyboardInternal(cn);
        if (internal) {
            if (gB)      { method_setImplementation(m, (IMP)NNTNilInputAccessoryView); nB++; }
            else if (gC) { method_setImplementation(m, NNTHidingWrapper(m, sel));      nC++; }
            else         { continue; }                      // 默认不碰
        } else {
            if (!gA) continue;
            method_setImplementation(m, (IMP)NNTNilInputAccessoryView);
            nA++;
        }
        CFSetAddValue(done, m);
    }
    free(classes);
    NNTLog(@"[处理完成] 界面类→nil: %d, 键盘内部类→nil: %d, 键盘内部类→隐藏: %d", nA, nB, nC);
}

#pragma mark - Hook

%hook UIInputSetHostView
- (void)layoutSubviews {
    %orig;
    if (gEnabled && gE) NNTSweep(self, 0);
}
%end

%group gWindowHook
%hook UIWindow
- (void)layoutSubviews {
    %orig;
    NNTDumpOnce();
    NNTSweepWindows();
}
%end
%end

#pragma mark - 入口

%ctor {
    if ([[NSFileManager defaultManager] fileExistsAtPath:@"/var/mobile/Media/NoNotesToolbar.off"]) gEnabled = NO;
    NNTLog(@"=== NoNotesToolbar v1.2 loaded, enabled=%d, pid=%d ===", gEnabled, getpid());
    NNTLog(@"日志路径: %@", NNTPath() ?: @"(全部失败)");
    if (!gEnabled) return;

    NNTLoadConfig();
    %init(gWindowHook);
    NNTPatchInputAccessoryViews();
